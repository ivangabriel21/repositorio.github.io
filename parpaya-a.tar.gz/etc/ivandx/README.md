# IvanDXScript

# Instalador del Script Ivandx

Este es el instalador para el Script Ivandx. Sigue los pasos a continuación para instalar el script en tu sistema.

## Instrucciones de Instalación

1. Ejecuta Este Comando En tu sistema Debian/Ubuntu:
```bash
apt update; apt upgrade -y; wget https://raw.githubusercontent.com/ivangabriel21/IvanDXScript/main/install; chmod 777 install; ./install --IvanDX
```

En este archivo `Readme.md`, he proporcionado las instrucciones para cada paso del proceso de instalación
